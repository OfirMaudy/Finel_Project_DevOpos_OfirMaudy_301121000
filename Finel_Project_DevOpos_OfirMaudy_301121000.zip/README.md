All applications to display the projects can be installed with the bash script I created, it is called: DevOpsSoftwareInstaller
